package com.capgemini.labs.Jdbclesson1;

public class ItemsList {

	private String Items;

	public String getItems() {
		return Items;
	}

	public void setItems(String items) {
		Items = items;
	}
	
}
